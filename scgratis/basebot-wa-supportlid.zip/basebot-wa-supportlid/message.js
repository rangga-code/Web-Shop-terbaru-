require("./config.js");
const chalk = require("chalk");
const fs = require("fs");
const util = require("util");
const { exec, spawn, execSync } = require('child_process');
const { prepareWAMessageMedia, generateWAMessageFromContent } = require("baileys");
const loadDb = require("./lib/load_database.js");

module.exports = async (sock, m) => {
  await loadDb(sock, m);
  const isCmd = m?.body?.startsWith(prefix);
  const quoted = m.quoted ? m.quoted : m;
  const mime = quoted?.msg?.mimetype || quoted?.mimetype || null;
  const args = m?.body?.trim().split(/ +/).slice(1) || [];
  const qmsg = m.quoted || m;
  const text = args.join(" ");
  const command = isCmd
    ? m.body.slice(prefix.length).trim().split(" ").shift().toLowerCase()
    : "";
  const cmd = prefix + command;
  const isOwner = m.isOwner
  const metadata = m.isGroup
    ? await global.groupMetadataCache.get(m.chat).catch(() => ({}))
    : {};
  const admins = metadata?.participants
    ? metadata.participants.filter(p => p.admin !== null).map(p => p.id)
    : [];
  m.isAdmin = m.isGroup && admins ? admins.includes(m.sender) : false
  m.isBotAdmin = m.isGroup && admins ? admins.includes(m.botNumber) : false
    
    const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `By ${namaOwner}`}}}

  if (isCmd) {
    console.log(
      chalk.white("• Sender  :"), chalk.blue(m.chat),
      "\n" + chalk.white("• Group   :"), chalk.blue(m.isGroup ? metadata.subject : "Private"),
      "\n" + chalk.white("• Command :"), chalk.blue(cmd),
      "\n"
    );
  }


  switch (command) {
  
    case "menu": {
    let teks = `
Hii @${m.sender.split("@")[0]}

*# Storemenu*
 .pushkontak
 .jpm
 
*# Channelmenu*
 .idch
    `
    return m.reply(teks)
    }
    break

case "jasher":
case "jpm":
case "jaser": {
  if (!isOwner) return m.reply(mess.owner);
  if (!text) return m.reply(`*Contoh Penggunaan:*
${cmd} pesannya & bisa dengan foto juga`);
  let mediaPath;
  if (/image/.test(mime)) {
    mediaPath = await m.quoted ? await m.quoted.download() : await m.download()
  }
  const allGroups = await sock.groupFetchAllParticipating();
  const groupIds = Object.keys(allGroups);
  let successCount = 0;
  let fail = 0;
  let bl = 0;
  await m.reply(`🚀 Memproses ${mediaPath ? "Jpm Teks & Foto" : "Jpm Teks"}
  
- Total Grup: ${groupIds.length}`);
  for (const id of groupIds) {
    try {
      if (mediaPath) {
        await sock.sendMessage(id, {
          image: mediaPath,
          caption: text
        });
      } else {
        await sock.sendMessage(id, { text });
      }
      successCount++;
    } catch (e) {
      fail += 1
      console.error(`Gagal kirim ke grup ${id}:`, e);
    }
    await sleep(4000);
  }
  await sock.sendMessage(m.chat, {
    text: `Jpm ${mediaPath ? "Teks & Foto" : "Teks"} berhasil dikirim ✅
    
Berhasil: ${successCount}
Gagal: ${fail}
Blacklist: ${bl}`
  }, { quoted: m });
}
break;

case "stalkch":
case "sch":
case "idch":
case "cekidch": {
    if (!text) return m.reply(`*Contoh:* ${cmd} link/id channel`)
    if (!text.includes("https://whatsapp.com/channel/") && !text.includes("@newsletter"))
        return m.reply("Link atau id channel tidak valid")

    let result = text.trim(), opsi = "jid"
    if (text.includes("https://whatsapp.com/channel/")) {
        result = text.split("https://whatsapp.com/channel/")[1]
        opsi = "invite"
    }

    const res = await sock.newsletterMetadata(opsi, result)
    const teks =
        `*Channel Information 🌍*\n\n` +
        `- Nama: ${res.name}\n` +
        `- Total Pengikut: ${toRupiah(res.subscribers)}\n` +
        `- ID: ${res.id}\n` +
        `- Link: https://whatsapp.com/channel/${res.invite}`

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: { text: teks },
                    nativeFlowMessage: {
                        buttons: [
                            { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "Copy Channel ID", copy_code: res.id }) }
                        ]
                    }
                }
            }
        }
    }, { userJid: m.sender, quoted: m })

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}
break

case "pushkontak":
case "puskontak": {
  if (!isOwner) return m.reply(mess.owner);
  if (!text) return m.reply(`*Contoh:* ${cmd} isi pesan`);

  global.textpushkontak = text;

  const groups = await sock.groupFetchAllParticipating();
  if (!groups || Object.keys(groups).length === 0)
    return m.reply("❌ Bot tidak tergabung di grup manapun.");

  global.dataAllGrup = groups;

  const rows = Object.values(groups).map(g => ({
    title: g.subject || "Tanpa Nama",
    description: `👥 ${g.participants.length} member`,
    id: `.pushkontak-response ${g.id}`
  }));

  await sock.sendMessage(m.chat, {
    text: `📢 *PUSH KONTAK*\n\nSilahkan pilih grup target:`,
    viewOnce: true,
    buttons: [
      {
        buttonId: "select_gc",
        buttonText: { displayText: "📂 Pilih Grup" },
        type: 4,
        nativeFlowInfo: {
          name: "single_select",
          paramsJson: JSON.stringify({
            title: "Daftar Grup",
            sections: [
              {
                title: "Pilih Target Grup",
                rows
              }
            ]
          })
        }
      }
    ],
    headerType: 1
  }, { quoted: m });
}
break;

case "pushkontak-response": {
  if (!isOwner) return m.reply(mess.owner);

  if (!global.textpushkontak || !global.dataAllGrup)
    return m.reply(
      "❌ Data pushkontak tidak ditemukan\nSilahkan ulangi dengan *.pushkontak pesan*"
    );

  const groupId = text;
  const groupData = global.dataAllGrup[groupId];
  if (!groupData) return m.reply("❌ Grup tidak ditemukan.");

  const messageText = global.textpushkontak;

  const members = groupData.participants
    .map(v => v.id)
    .filter(jid => jid && jid !== botNumber);

  await m.reply(
    `🚀 *Memulai Pushkontak*\n\n` +
    `📌 Grup : *${groupData.subject}*\n` +
    `👥 Total : *${members.length} member*`
  );

  let success = 0;

  for (const jid of members) {
    try {
      await sock.sendMessage(jid, { text: messageText }, { quoted: qtext });
      success++;
      await sleep(4000); // delay aman
    } catch (e) {
      console.log("Gagal kirim ke:", jid);
    }
  }

  delete global.textpushkontak;
  delete global.dataAllGrup;

  return m.reply(
    `✅ *Pushkontak Selesai*\n\n` +
    `📤 Berhasil terkirim ke *${success} member*`
  );
}
break;
    
    
  default:
if (m.body.toLowerCase().startsWith("xx ")) {
  if (!isOwner) return;
  try {
    const r = await eval(`(async()=>{${text}})()`);
    sock.sendMessage(m.chat, { text: util.format(typeof r === "string" ? r : util.inspect(r)) }, { quoted: m });
  } catch (e) {
    sock.sendMessage(m.chat, { text: util.format(e) }, { quoted: m });
  }
}

if (m.body.toLowerCase().startsWith("x ")) {
  if (!isOwner) return;
  try {
    let r = await eval(text);
    sock.sendMessage(m.chat, { text: util.format(typeof r === "string" ? r : util.inspect(r)) }, { quoted: m });
  } catch (e) {
    sock.sendMessage(m.chat, { text: util.format(e) }, { quoted: m });
  }
}

if (m.body.startsWith('$ ')) {
  if (!isOwner) return;
  exec(m.body.slice(2), (e, out) =>
    sock.sendMessage(m.chat, { text: util.format(e ? e : out) }, { quoted: m })
  );
}

  }
};


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
delete require.cache[file]
require(file)
})